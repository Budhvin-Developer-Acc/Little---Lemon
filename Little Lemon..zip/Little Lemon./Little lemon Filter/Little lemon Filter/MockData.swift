//
//  MockData.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import Foundation

struct MockData {
    static let foodMenuItems: [MenuItem] = [
        MenuItem(title: "Pizza", ingredients: [.tomatoSauce, .cheese, .pepperoni]),
        // Add more food menu items
    ]
    
    static let drinkMenuItems: [MenuItem] = [
        MenuItem(title: "Coke", ingredients: []),
        // Add more drink menu items
    ]
    
    static let dessertMenuItems: [MenuItem] = [
        MenuItem(title: "Chocolate Cake", ingredients: [.chocolate]),
        // Add more dessert menu items
    ]
}

