//
//  MenuItemTests.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import XCTest
@testable import YourAppName

class MenuItemTests: XCTestCase {
    func testMenuItemTitle() {
        let menuItem = MenuItem(title: "Test", ingredients: [.broccoli])
        XCTAssertEqual(menuItem.title, "Test")
    }
    
    func testMenuItemIngredients() {
        let menuItem = MenuItem(title: "Test", ingredients: [.broccoli, .carrot])
        XCTAssertEqual(menuItem.ingredients, [.broccoli, .carrot])
    }
}
