//
//  MenuCategory.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import Foundation

enum MenuCategory: String, CaseIterable {
    case food = "Food"
    case drink = "Drink"
    case dessert = "Dessert"
}

