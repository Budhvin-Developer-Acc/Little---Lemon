//
//  Ingredient.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import Foundation

enum Ingredient: String, CaseIterable {
    case spinach
    case broccoli
    case carrot
    case pasta
    case tomatoSauce = "Tomato sauce"
}
