//
//  MenuItem.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import Foundation

struct MenuItem: Identifiable {
    let id = UUID()
    let title: String
    let ingredients: [Ingredient]
}

extension MenuItem: MenuItemProtocol {
    var ordersCount: Int {
        get {
            // Your implementation
            return 0
        }
        set {
            // Your implementation
        }
    }
    
    var price: Double {
        get {
            // Your implementation
            return 0.0
        }
        set {
            // Your implementation
        }
    }
    
    var menuCategory: MenuCategory {
        // Return the category based on the ingredients or any other logic
        return .food
    }
}

