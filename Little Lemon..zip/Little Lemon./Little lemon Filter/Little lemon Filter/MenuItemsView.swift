//
//  MenuItemsView.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import SwiftUI

struct MenuItemsView: View {
    @StateObject var viewModel = MenuViewViewModel()
    @State private var showingOptions = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    // Your menu items grid layout here
                }
            }
            .navigationBarItems(trailing:
                Button(action: {
                    self.showingOptions.toggle()
                }) {
                    Image(systemName: "slider.horizontal.3")
                }
            )
        }
        .sheet(isPresented: $showingOptions) {
            MenuItemsOptionView()
        }
    }
}
