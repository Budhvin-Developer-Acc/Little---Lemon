//
//  MenuItemsOptionView.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import SwiftUI

struct MenuItemsOptionView: View {
    enum SelectedCategory: String, CaseIterable {
        case food = "Food"
        case drink = "Drink"
        case dessert = "Dessert"
    }
    
    enum SortOption: String, CaseIterable {
        case mostPopular = "Most Popular"
        case price = "Price $-$$$"
        case name = "A-Z"
    }
    
    var body: some View {
        VStack {
            Text("SELECTED CATEGORIES").font(.headline)
            // Your code for displaying selected categories
            
            Divider()
            
            Text("SORT BY").font(.headline)
            // Your code for displaying sort options
        }
        .padding()
    }
}

