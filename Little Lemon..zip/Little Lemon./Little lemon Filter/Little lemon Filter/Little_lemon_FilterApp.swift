//
//  Little_lemon_FilterApp.swift
//  Little lemon Filter
//
//  Created by Budhvin Nawarathne on 2024-03-07.
//

import SwiftUI

@main
struct Little_lemon_FilterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
