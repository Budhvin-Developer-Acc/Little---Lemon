import SwiftUI

@main
struct StartingProjectApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
